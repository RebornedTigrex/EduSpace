#pragma once
#include <boost/asio.hpp>
#include <boost/beast.hpp>
#include <functional>
#include <string>
#include <thread>
#include <mutex>

class cWsClient {
public:
    using tOnMessage = std::function<void(const std::string&)>;

    cWsClient();
    ~cWsClient();

    bool connect(const std::string& host, int port, const std::string& path = "/");
    void close();

    void setOnMessage(tOnMessage cb) { m_onMessage = std::move(cb); }

    void sendText(const std::string& s);

private:
    void runThread();
    void doRead();

private:
    boost::asio::io_context m_ioc;
    boost::asio::ip::tcp::resolver m_resolver;
    boost::beast::websocket::stream<boost::beast::tcp_stream> m_ws;
    boost::beast::flat_buffer m_buffer;

    std::thread m_thr;
    std::mutex m_sendMtx;

    tOnMessage m_onMessage;
    bool m_connected{ false };
};
