#include "cWsClient.h"
#include <iostream>

namespace beast = boost::beast;
namespace websocket = beast::websocket;
using tcp = boost::asio::ip::tcp;

cWsClient::cWsClient()
    : m_resolver(m_ioc), m_ws(m_ioc)
{
}

cWsClient::~cWsClient() { close(); }

bool cWsClient::connect(const std::string& host, int port, const std::string& path)
{
    try {
        auto const results = m_resolver.resolve(host, std::to_string(port));
        auto ep = beast::get_lowest_layer(m_ws).connect(results);

        // handshake
        m_ws.handshake(host + ":" + std::to_string(port), path);
        m_connected = true;

        doRead();
        m_thr = std::thread([this] { runThread(); });
        return true;
    }
    catch (const std::exception& e) {
        std::cerr << "[WSCLIENT] connect error: " << e.what() << "\n";
        return false;
    }
}

void cWsClient::runThread()
{
    try { m_ioc.run(); }
    catch (...) {}
}

void cWsClient::doRead()
{
    m_ws.async_read(m_buffer, [this](beast::error_code ec, std::size_t bytes)
        {
            if (ec) {
                m_connected = false;
                return;
            }

            std::string msg = beast::buffers_to_string(m_buffer.data());
            m_buffer.consume(bytes);

            if (m_onMessage) m_onMessage(msg);
            doRead();
        });
}

void cWsClient::sendText(const std::string& s)
{
    if (!m_connected) return;
    std::lock_guard<std::mutex> lg(m_sendMtx);

    beast::error_code ec;
    m_ws.text(true);
    m_ws.write(boost::asio::buffer(s), ec);
}

void cWsClient::close()
{
    if (!m_connected) return;
    m_connected = false;

    beast::error_code ec;
    m_ws.close(websocket::close_code::normal, ec);

    m_ioc.stop();
    if (m_thr.joinable()) m_thr.join();
}
