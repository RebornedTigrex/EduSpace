﻿#include "cConferenceNet.h"
#include <nlohmann/json.hpp>
#include <thread>

using json = nlohmann::json;

bool cConferenceNet::start(const std::string& host, int port)
{
    m_ws.setOnMessage([this](const std::string& s) { onWsMessage(s); });
    if (!m_ws.connect(host, port, "/")) return false;

    m_audio.init(48000, 1, 480);
    m_audio.startPlayback();

    m_opus.init(48000, 1);
    return true;
}

void cConferenceNet::stop()
{
    stopAudio();
    m_rtc.close();
    m_ws.close();
    m_opus.shutdown();
    m_audio.shutdown();
}

std::string cConferenceNet::createConference(const std::string& title, const std::string& peerKey)
{
    m_peerKey = peerKey;
    m_gotCreate = false;
    m_lastInvite.clear();

    json j{
        {"type","conf_create"},
        {"title", title},
        {"peer", peerKey}
    };
    m_ws.sendText(j.dump());

    // ждём ответ (упрощённо)
    for (int i = 0; i < 200; ++i) { // ~2s
        if (m_gotCreate) break;
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
    return m_lastInvite;
}

bool cConferenceNet::joinByInvite(const std::string& invite, const std::string& peerKey)
{
    m_peerKey = peerKey;
    m_gotJoin = false;
    m_joinOk = false;

    json j{
        {"type","conf_join"},
        {"invite", invite},
        {"peer", peerKey}
    };
    m_ws.sendText(j.dump());

    for (int i = 0; i < 200; ++i) {
        if (m_gotJoin) break;
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
    if (!m_joinOk) return false;

    // стартуем WebRTC к серверу (offer уйдёт через ws callback)
    m_rtc.init(peerKey, [this](const std::string& sig) {
        m_ws.sendText(sig);
        });

    // принимаем incoming audio
    m_rtc.setOnBinary([this](const std::vector<uint8_t>& data) {
        auto pcm = m_opus.decode(data.data(), (int)data.size(), 960);
        if (!pcm.empty()) m_audio.pushToPlayback(pcm.data(), (int)pcm.size());
        });

    startAudio();
    m_joined = true;
    return true;
}

void cConferenceNet::startAudio()
{
    // capture → opus → rtc.sendBinary
    m_audio.startCapture([this](const int16_t* pcm, int frameSamples) {
        if (!m_joined) return;
        auto pkt = m_opus.encode(pcm, frameSamples);
        if (!pkt.empty()) m_rtc.sendBinary(pkt);
        });
}

void cConferenceNet::stopAudio()
{
    m_audio.stopCapture();
    m_joined = false;
}

void cConferenceNet::onWsMessage(const std::string& msg)
{
    try {
        json j = json::parse(msg);
        const std::string type = j.value("type", "");

        if (type == "conf_created") {
            m_lastInvite = j.value("invite", "");
            m_gotCreate = true;
        }
        else if (type == "conf_joined") {
            m_joinOk = j.value("ok", false);
            m_gotJoin = true;
        }
        else if (type == "webrtc_answer") {
            if (j.value("peer", "") == m_peerKey)
                m_rtc.onAnswer(j.value("sdp", ""));
        }
        else if (type == "webrtc_ice") {
            if (j.value("peer", "") == m_peerKey)
                m_rtc.onIce(j.value("sdpMid", ""), j.value("candidate", ""));
        }
    }
    catch (...) {}
}
