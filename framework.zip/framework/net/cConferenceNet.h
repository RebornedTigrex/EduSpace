#pragma once
#include "cWsClient.h"
#include "cRtcClientPeer.h"
#include "cAudioIO.h"
#include "cOpusCodec.h"

#include <string>
#include <atomic>
#include <mutex>
#include <condition_variable>
#include <chrono>

// Сеть/RTC/Аудио для конференций.
// - WS: команды conf_create/conf_join/conf_leave/conf_mic + signaling webrtc_*
// - RTC: DataChannel "audio" для Opus пакетов
// - Audio: PortAudio capture/playback
class cConferenceNet {
public:
    cConferenceNet() = default;
    ~cConferenceNet() { stop(); }

    // Подключиться к серверу + подготовить аудио подсистемы (playback+opus).
    bool start(const std::string& host = "127.0.0.1", int port = 9000, const std::string& path = "/");
    void stop();

    // Создать конференцию. peerKey будет автоматически "починен" (добавится суффикс уникальности).
    // Возвращает invite-код (или пустую строку если ошибка).
    std::string createConference(const std::string& title, const std::string& peerKeyBase);

    // Присоединиться по invite. peerKey также будет "починен".
    bool joinByInvite(const std::string& invite, const std::string& peerKeyBase);

    // Выйти из конференции (корректно остановить capture, закрыть RTC, сообщить серверу).
    void leave();

    // Управление микрофоном. При выключении:
    // - захват (capture) можно остановить, чтобы CPU/устройство не занимать
    // - или просто не отправлять (оба режима ок). Здесь сделано "не отправлять" (аудиозахват остаётся)
    //   и дополнительно посылаем серверу conf_mic, чтобы UI у других мог обновляться (если сервер реализует).
    void setMicEnabled(bool en);
    bool isMicEnabled() const { return m_micEnabled.load(); }

    bool isInConference() const { return m_joined.load(); }
    int  lastConfId() const { return m_confId.load(); }
    std::string lastInvite() const;

    std::string peerKey() const { return m_peerKey; }

    // Таймаут ожидания ответов от сервера (create/join)
    void setServerWaitTimeout(std::chrono::milliseconds t) { m_waitTimeout = t; }

private:
    void onWsMessage(const std::string& msg);

    bool startRtc();      // поднять PeerConnection/DC и signaling
    void stopRtc();

    bool startAudio();    // startCapture (если ещё не запущен)
    void stopAudio();

    bool ensurePeerKey(const std::string& peerKeyBase);

    static std::string makePeerKeySuffix();

private:
    cWsClient       m_ws;
    cRtcClientPeer  m_rtc;
    cAudioIO        m_audio;
    cOpusCodec      m_opus;

    std::string m_peerKey;

    std::atomic<bool> m_joined{ false };
    std::atomic<bool> m_micEnabled{ true };
    std::atomic<int>  m_confId{ -1 };

    // ожидания create/join
    mutable std::mutex m_mtx;
    std::condition_variable m_cv;

    bool m_gotCreate{ false };
    bool m_gotJoin{ false };
    bool m_joinOk{ false };
    std::string m_lastInvite;

    std::chrono::milliseconds m_waitTimeout{ 2000 };
};

